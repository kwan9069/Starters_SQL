package jdbc;

public class ConnectionInform {
	public final static String DRIVER_CLASS = "org.mariadb.jdbc.Driver";
	public final static String JDBC_URL = "jdbc:mariadb://localhost:3306/memberdb";
	public final static String USERNAME = "jdbc";
	public final static String PASSWORD = "jdbc";
	
}
