package jdbc;

public class MonthEmployee {
	
	ArrayList getEmployees() {
		
	}
	
	public static void main(String[] args) {
		
		new MonthEmployee().getEmployees();
		/*  * 키보드로 입력 
	     * 
	     * 제외할 월 : 3
	     * 01-12 사이 값 입력시 월별 입사자 총급여 조회
	     * 입사월 급여총합
	     * 01   xxx
	     * 02   xxx
	     * 04   xxx
	     * ....
	     * 12   xxx
	     *  */
	}

}
