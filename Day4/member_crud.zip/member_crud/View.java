package member_crud;

public interface View {
	void input();
}
